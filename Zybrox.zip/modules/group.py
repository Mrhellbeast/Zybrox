__help__ = """
 ❍ /setgtitle <newtitle>*:* Sets new chat title in your group.
 ❍ /setgpic*:* As a reply to file or photo to set group profile pic!
 ❍ /delgpic*:* Same as above but to remove group profile pic.
 ❍ /setsticker*:* As a reply to some sticker to set it as group sticker set!
 ❍ /setdescription <description>*:* Sets new chat description in group.
"""

__mod_name__ = "GROUP"
